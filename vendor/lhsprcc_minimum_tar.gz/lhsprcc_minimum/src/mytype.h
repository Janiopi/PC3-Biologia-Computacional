#define MYdouble long double
